import Image from "next/image"

export default function Hero() {
  return (
    <section className="relative flex min-h-[calc(100vh-88px)] flex-col lg:flex-row">
      {/* Left side - Text content */}
      <div className="flex flex-1 items-center justify-center bg-secondary px-6 py-12 lg:px-16 lg:py-24">
        <div className="max-w-lg space-y-6">
          {/* Salutation */}
          <div className="mb-2">
            <h1 className="text-4xl font-bold text-card sm:text-5xl lg:text-6xl">
              Salut,
            </h1>
            <h1 className="text-4xl font-bold text-card sm:text-5xl lg:text-6xl">
              Je suis <span className="bg-primary text-card px-2">Amir</span>
            </h1>
          </div>

          {/* Title */}
          <div className="border-l-4 border-primary pl-4">
            <h2 className="text-2xl font-semibold text-card sm:text-3xl lg:text-4xl">
              Développeur Full-Stack
            </h2>
          </div>

          {/* Description */}
<div className="space-y-3">
  <p className="text-lg text-card leading-relaxed">
    Ingénieur en génie logiciel passionné par le développement web moderne et 
    l'<span className="font-semibold">intelligence artificielle</span> — de la conception backend avec 
    <span className="font-semibold"> Node.js/Express.js</span> à la création d’interfaces performantes avec 
    <span className="font-semibold"> React.js/Next.js</span>, le tout soutenu par des pratiques 
    <span className="font-semibold"> DevOps</span> solides.
  </p>
</div>


          {/* CTA Button */}
          <div className="pt-4">
            <button className="bg-primary text-card px-8 py-3 text-lg font-semibold border-2 border-card hover:bg-primary/90 hover:scale-105 transition-all duration-200">
              Voir le CV
            </button>
          </div>
        </div>
      </div>

      {/* Right side - Image */}
      <div className="relative flex-1 bg-muted">
        <div className="relative h-full min-h-[400px] lg:min-h-full">
          <Image
            src="/professional-business-consultant-portrait-black-an.jpg"
            alt="Portrait professionnel d'Amir"
            fill
            className="object-cover grayscale hover:grayscale-0 transition-all duration-500"
            priority
          />
          {/* Overlay gradient */}
          <div className="absolute inset-0 bg-gradient-to-r from-secondary/20 to-transparent lg:bg-gradient-to-l" />
        </div>
      </div>

      {/* Yellow accent stripe - right edge */}
      <div className="absolute right-0 top-0 h-full w-2 bg-primary lg:w-3" />

      {/* Yellow accent stripe - bottom edge */}
      <div className="absolute bottom-0 left-0 h-2 w-full bg-primary lg:h-3" />

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden lg:block">
        <div className="animate-bounce">
          <div className="w-6 h-10 border-2 border-card rounded-full flex justify-center">
            <div className="w-1 h-3 bg-card rounded-full mt-2" />
          </div>
        </div>
      </div>
    </section>
  )
}
