"use client"

import Link from "next/link"
import { useState } from "react"

const navItems = [
  { name: "ACCUEIL", href: "#accueil" },
  { name: "À PROPOS", href: "#apropos" },
  { name: "EXPÉRIENCE", href: "#experience" },
  { name: "COMPÉTENCES", href: "#competences" },
  { name: "PROJETS", href: "#projets" },
  { name: "RÉSUMÉ", href: "#resume" },
  { name: "CONTACT", href: "#contact" },
]

export default function Header() {
  const [activeItem, setActiveItem] = useState("ACCUEIL")

  return (
    <header className="bg-card text-card-foreground sticky top-0 z-50">
      <div className="mx-auto flex items-center justify-between px-8 py-5 lg:px-16">
        <Link href="#accueil" className="flex flex-col leading-none">
          <span className="text-2xl font-bold tracking-[0.3em] lg:text-3xl">
            <span className="text-primary">AMIR</span>
          </span>
          <span className="text-xl font-bold tracking-[0.3em] pl-4 lg:text-2xl lg:pl-6">HJIRI</span>
        </Link>

        {/* Navigation */}
        <nav className="hidden lg:block">
          <ul className="flex items-center gap-8">
            {navItems.map((item) => (
              <li key={item.name}>
                <Link
                  href={item.href}
                  onClick={() => setActiveItem(item.name)}
                  className="relative text-sm font-semibold tracking-wide transition-colors hover:text-primary"
                >
                  {item.name}
                  {activeItem === item.name && <span className="absolute -bottom-5 left-0 h-1 w-full bg-primary" />}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        {/* Mobile menu button */}
        <button className="lg:hidden text-card-foreground">
          <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>
    </header>
  )
}
